
/* @ Groovy Class
 * methods to fetch API key ,Account Id and preAuthAmount from Spring configuration file
 */

import org.mule.api.MuleContext
import org.mule.context.DefaultMuleContextFactory
import org.mule.api.MuleMessage
class ClientTokenDetails {
    
	/*@method
	 * Lookup in Spring configuration file
	 * Returns API key and AccountId based on the legal entity and currency
	 * 
	 */
		
	  public getApikeyAndMerchantId(String legalEntity, String currencyIn, MuleContext muleContext,MuleMessage message){
		  String currency=currencyIn.toUpperCase()
            if (muleContext.getRegistry().get("merchant_information")[currency] !=null && currency.equalsIgnoreCase(muleContext.getRegistry().get("merchant_information")[currency].Currency)){
            if((currency.equalsIgnoreCase(muleContext.getRegistry().get("merchant_information")[currency].Currency)) && (legalEntity.equalsIgnoreCase(muleContext.getRegistry().get("merchant_information")[currency].LegalEntity))) {
                  message.setInvocationProperty('Account_Id',muleContext.getRegistry().get("merchant_information")[currency].MerchantId)
                       message.setInvocationProperty('Apikey',"Basic "+muleContext.getRegistry().get("merchant_information")[currency].APIKey)
                  }  else {
                        throw new IllegalArgumentException("LegalEntityAndCurrencyMismatch");
                  }
            }
            else     {
                  throw new IllegalArgumentException("LegalEntityAndCurrencyMismatch"+"Invalid currnecy");
            }
      }
	  
	  /*@method
	   * Lookup in Spring configuration file
	   * Returns preAuthAmount based on the legal entity and currency
	   *
	   */
     public getPreAuthAmount(String legalEntity, String currency, MuleContext muleContext){
		String preAuthAmount;
		if (muleContext.getRegistry().get("merchant_information")[currency] !=null && currency.equals(muleContext.getRegistry().get("merchant_information")[currency].Currency)){
			if((currency.equals(muleContext.getRegistry().get("merchant_information")[currency].Currency)) && (legalEntity.equals(muleContext.getRegistry().get("merchant_information")[currency].LegalEntity))) {
				preAuthAmount= muleContext.getRegistry().get("merchant_information")[currency].PreAuthAmount
			}  else{
				throw new IllegalArgumentException("LegalEntityAndCurrencyMismatch");
			}
		}
		else     {
                  throw new IllegalArgumentException("LegalEntityAndCurrencyMismatch"+"Invalid currnecy");
            }
		return preAuthAmount;
		
	}
}
